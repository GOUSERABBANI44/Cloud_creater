# Terraform-script
Create All AWS resources
